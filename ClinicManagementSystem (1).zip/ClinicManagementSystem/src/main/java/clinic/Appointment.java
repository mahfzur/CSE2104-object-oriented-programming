/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package clinic;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
/**
 *
 * @author ANIK
 */
public class Appointment {
    private Doctor doctor;
    private Patient patient;
    private String date;

    public Appointment(Doctor doctor, Patient patient, String date) {
        this.doctor = doctor;
        this.patient = patient;
        this.date = date;
    }

    public void saveAppointment() {
        String appointmentDetails = "Doctor: " + doctor.getName() + ", Patient: " + patient.getName() + ", Date: " + date;
        
        // Specify the absolute path to the appointments.txt file
       String filePath = "F:\\sumaiya the V.I.P\\sem 14\\OOP\\assignments\\final 2\\ClinicManagementSystem\\src\\appointments.txt";
        
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath, true))) {
            writer.write(appointmentDetails);
            writer.newLine();
            System.out.println("Appointment saved successfully."); // Confirmation message
        } catch (IOException e) {
            e.printStackTrace(); // Print stack trace for debugging
            System.out.println("Error saving appointment: " + e.getMessage());
        }
    }
}
