/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package clinic;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
/**
 *
 * @author ANIK
 */
public class ClinicManagementSystem {
    private List<Doctor> doctors = new ArrayList<>();
    private List<Patient> patients = new ArrayList<>();

    public ClinicManagementSystem() {
        // Sample doctors
        doctors.add(new GeneralPractitioner("Dr. Sultana"));
        doctors.add(new Specialist("Dr. Shamima"));
    }

    public void registerPatient(String name, String contact) {
        patients.add(new Patient(name, contact));
        System.out.println("Patient registered successfully: " + name);
    }

    public void viewDoctors() {
        System.out.println("Available Doctors:");
        for (Doctor doctor : doctors) {
            System.out.println("- " + doctor.getName() + " (" + doctor.getSpecialization() + ")");
            doctor.displayAvailability();
        }
    }

    public void bookAppointment(String patientName, String doctorName, String date) {
        Doctor selectedDoctor = null;
        for (Doctor doctor : doctors) {
            if (doctor.getName().equals(doctorName)) {
                selectedDoctor = doctor;
                break;
            }
        }
        if (selectedDoctor != null) {
            Patient patient = new Patient(patientName, "Contact Info"); // Simplified for demo
            Appointment appointment = new Appointment(selectedDoctor, patient, date);
            appointment.saveAppointment();
            System.out.println("Appointment booked for " + patientName + " with " + doctorName + " on " + date);
        } else {
            System.out.println("Doctor not found.");
        }
    }

    public static void main(String[] args) {
        ClinicManagementSystem system = new ClinicManagementSystem();
        Scanner scanner = new Scanner(System.in);

        // Sample interaction
        system.registerPatient("Sumaiya", "123456789");
        system.viewDoctors();
        system.bookAppointment("Sumaiya", "Dr. Sultana", "2024-09-15");

        scanner.close();
    }
}